<?php

namespace Moorexa;

/**
 *@package Model Service Manager
 *@Note: Provides a mechanism for data communication between multiple Models.
*/
