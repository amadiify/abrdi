<?php

namespace Moorexa;

/**
*@package View Service Manager
*@Note: Provides a mechanism for data communication between multiple Views
*/
