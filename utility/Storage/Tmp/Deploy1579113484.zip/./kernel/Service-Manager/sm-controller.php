<?php

namespace Moorexa;

/**
 *@package Controller Service Manager
 *@info Provides a mechanism for data communication between multiple Controllers
*/

boot()->get('Config')->loadPageInformation();