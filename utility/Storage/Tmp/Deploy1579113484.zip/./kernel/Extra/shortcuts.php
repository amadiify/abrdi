<?php

$kernel->shortcuts([
	'sm-func' => PATH_TO_LIB . 'sm-func.php'
]);