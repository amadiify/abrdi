<?php
// Assist manager for packages
return [
    // version control manager
    'VCM' => [
        'path' => 'lab/VCSManager/',
        'assist' => 'lab/VCSManager/launcher.php'
    ],
    'GDI' => [
        'path' => 'lab/Cms/',
        'assist' => 'lab/Cms/Console.php'
    ]
];