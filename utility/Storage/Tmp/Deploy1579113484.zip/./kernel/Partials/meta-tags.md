<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html">
<meta name="author" content="{$package->author}">
<meta name="description" content="{$package->description}">
<meta name="keywords" content="{$package->keywords}">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=noja">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="cache-control" content="no-cache">
<meta http-equiv="expires" content="0">
<meta name="robots" content="index, follow">