<?php

$kernel->authentication(function(Authenticate $auth)
{
    // load authentication handlers
});