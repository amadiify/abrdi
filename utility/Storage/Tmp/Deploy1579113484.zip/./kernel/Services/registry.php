<?php

/**
 * @package Application Registry for global providers
 */
$kernel->registry([
    'boot' => [
    ]
]);