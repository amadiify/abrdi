<?php

namespace Moorexa;

// Add global middlewares here..