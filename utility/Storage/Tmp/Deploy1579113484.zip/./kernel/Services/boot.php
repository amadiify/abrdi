<?php

namespace Moorexa;

use utility\Classes\BootMgr\Manager as Boot;

/**
 * @package Boot Manager
 */

 // registered in /Config/aliases.php
 \Cms\Config::loadBoot();
